   <!--  <a href="?section=accueil" id="selecAcceuil">Accueil</a> -->

    <a href="?section=cours" id="seleccours">LET'S START</a>
</div>
