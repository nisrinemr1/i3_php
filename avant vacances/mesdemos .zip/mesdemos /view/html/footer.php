<p class="footer" id="copyright">© Nisrine Maruan - Web10 - Interface3</p>

<script src="public/js/script.js"></script>
</body>
</html>