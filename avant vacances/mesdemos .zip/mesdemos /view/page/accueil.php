<body>
    <section class="titleHome">        
            <h1 class="txtHome"> GLOBAL DEMO </h1>
        </section>
  
