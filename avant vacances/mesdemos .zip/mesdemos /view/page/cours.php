<br><br><br> 

<div class="bodyy">
<div> 
<section class="aside">
<aside>
    <p><ul>
        <li>HTML</li>
        <li>CSS</li>
        <li>JAVASCRIPT</li>
        <li>PHP</li>
    </ul></p>
</aside>
</section>
</div>

<div>
    <section class="articles">
        <article>
            <h2><a href="./cours/html.html">HTML</a></h2>
            <!-- pas la peine d'utiliser la nav, le a suffit car la nav permet de surfer sur internet -->
        </article> 

        <article>
            <h2><a href="./cours/css.html">CSS</a></h2>
        </article> 

        <article>
            <h2><a href="./cours/javscript.html ">Javascript</a></h2>
        </article>

        <article>
            <h2><a href="cours/phpmysql.html ">PHP</a></h2>
        </article>

        
    </section>
 <!-- Histoire de le mettre sous forme d'article -->
    </div>
</div>

<div style = "clear:both;"></div>
<footer>
    <div>
        <p>© Nisrine Maruan - 2021</p>
    </div>

</footer>