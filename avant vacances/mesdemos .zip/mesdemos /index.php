<?php 
    include("view/html/head.php");
    include("view/html/menu.php");
    include("controller/router.php");
    include("view/hmtl/router.php");
?>